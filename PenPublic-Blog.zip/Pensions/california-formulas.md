---
title: California Pension Formulas
description: Every CalPERS and CalSTRS retirement formula explained — Classic vs PEPRA, Miscellaneous vs Safety, benefit factors, final compensation, and how local agencies choose their formula
tags: ['CalPERS', 'CalSTRS', 'PEPRA', 'pensions', 'formulas', 'retirement', 'California']
---

# California Pension Formulas

All California public defined benefit pensions use the same fundamental formula:

> **Service Credit × Benefit Factor (Age Factor) × Final Compensation = Annual Pension**

The three variables:
- **Service Credit** — total years and partial years of employment
- **Benefit Factor (Age Factor)** — a percentage per year of service, determined by your retirement age and the formula in your plan
- **Final Compensation** — the highest average annual salary over a consecutive period (either 12 or 36 months, depending on your plan and hire date)

* see also: <a href="https://www.calpers.ca.gov/members/retirement-benefits/benefit-factor-charts">CalPERS Benefit Factor Charts</a>
* see also: <a href="./california">California Pension Systems Overview</a> — background on all 80+ systems, bargaining units, and MOUs

---

## CalPERS Formulas

CalPERS offers multiple retirement formulas. Which one applies to you depends on (a) your membership category (Miscellaneous or Safety), (b) when you were hired, and (c) <a href="https://www.calpers.ca.gov/employers/contracts/new-pension-contracts">your employer's contract with CalPERS</a>.

### State Miscellaneous & Industrial Members

| Formula | Applies To | Full Benefit Age | Max Factor | Min Retire Age | Final Comp Period |
|---------|-----------|-----------------|------------|----------------|-------------------|
| **2% @ 55** | Classic members hired before 1/15/2011 | 55 | 2.5% at 63+ | 50 | Highest 12 months |
| **2% @ 60** | Classic members hired 1/15/2011–12/31/2012 | 60 | 2.418% at 63+ | 50 | Highest 36 months |
| **2% @ 62** (PEPRA) | New members hired on/after 1/1/2013 | 62 | 2.5% at 67+ | 52 | Highest 36 months |
| **1.25% @ 65** | Older formula, some legacy members | 65 | — | — | — |

* see also: <a href="https://www.calpers.ca.gov/documents/state-miscellaneous-industrial-member-2-at-55-benefit-factors-pdf/download?inline=">CalPERS 2% at 55 Benefit Factors (PDF)</a>
* see also: <a href="https://www.calpers.ca.gov/documents/state-miscellaneous-industrial-member-2-at-60-benefit-factors-pdf/download?inline=">CalPERS 2% at 60 Benefit Factors (PDF)</a>
* see also: <a href="https://www.calpers.ca.gov/documents/state-miscellaneous-industrial-member-2-at-62-benefit-factors-pdf/download?inline=">CalPERS 2% at 62 Benefit Factors (PDF)</a>
* see also: <a href="https://www.calpers.ca.gov/documents/state-miscellaneous-industrial-member-125-at-65-benefit-factors-pdf/download?inline=">CalPERS 1.25% at 65 Benefit Factors (PDF)</a>
* see also: <a href="https://www.csudh.edu/Assets/csudh-sites/hr/docs/benefits/retirement-calpers/retirement-calpers-formula.pdf">CSU Dominguez Hills Retirement Formula Summary (PDF)</a>

### Local Miscellaneous (Public Agency) Members

Local agencies choose their formula through their CalPERS contract. Common classic formulas include:

| Formula | Full Benefit Age | Max Factor | Notes |
|---------|-----------------|------------|-------|
| **3% @ 60** | 60 | 3.0% | Most generous; some agencies (e.g., Riverside Tier I) |
| **2.7% @ 55** | 55 | 2.7% | Common pre-PEPRA |
| **2.5% @ 55** | 55 | 2.5% | Common pre-PEPRA |
| **2% @ 55** | 55 | 2.5% at 63+ | Common classic formula |
| **2% @ 60** | 60 | 2.418% at 63+ | Mid-range classic |
| **2% @ 62** (PEPRA) | 62 | 2.5% at 67+ | Required for all new members after 1/1/2013 |

* see also: <a href="https://rc-hr.com/files/2023-08/CalPERS_Retirement_Plan_Find_Out_More_2017.pdf">Riverside County CalPERS Retirement Formulas (PDF)</a>
* see also: <a href="https://www.calpers.ca.gov/documents/local-miscellaneous-member-3-at-60-benefit-factors-pdf/download?inline=">CalPERS Local Miscellaneous 3% at 60 Benefit Factors (PDF)</a>
* see also: <a href="https://www.calpers.ca.gov/documents/local-miscellaneous-member-27-at-55-benefit-factors-pdf/download?inline=">CalPERS Local Miscellaneous 2.7% at 55 Benefit Factors (PDF)</a>
* see also: <a href="https://www.calpers.ca.gov/documents/local-miscellaneous-member-25-at-55-benefit-factors-pdf/download?inline=">CalPERS Local Miscellaneous 2.5% at 55 Benefit Factors (PDF)</a>
* see also: <a href="https://www.calpers.ca.gov/documents/local-miscellaneous-member-2-at-55-benefit-factors-pdf/download?inline=">CalPERS Local Miscellaneous 2% at 55 Benefit Factors (PDF)</a>
* see also: <a href="https://www.calpers.ca.gov/documents/local-miscellaneous-member-2-at-60-benefit-factors-pdf/download?inline=">CalPERS Local Miscellaneous 2% at 60 Benefit Factors (PDF)</a>
* see also: <a href="https://www.calpers.ca.gov/documents/local-miscellaneous-member-2-at-62-benefit-factors-pdf/download?inline=">CalPERS Local Miscellaneous 2% at 62 (PEPRA) Benefit Factors (PDF)</a>

### Safety Members (Police, Fire, Corrections)

| Formula | Applies To | Full Benefit Age | Max Factor |
|---------|-----------|-----------------|------------|
| **3% @ 50** | Classic safety, pre-PEPRA | 50 | 3.0% |
| **3% @ 55** | Classic safety | 55 | 3.0% |
| **2.5% @ 55** | Classic safety | 55 | 2.5% |
| **2.7% @ 57** (PEPRA) | New safety members after 1/1/2013 | 57 | 2.7% |
| **2.5% @ 57** (PEPRA) | PEPRA safety option | 57 | 2.5% |
| **2% @ 57** (PEPRA) | PEPRA safety option | 57 | 2.0% |

* see also: <a href="https://www.calpers.ca.gov/documents/local-safety-member-3-at-50-benefit-factors-pdf/download?inline=">CalPERS Local Safety 3% at 50 Benefit Factors (PDF)</a>
* see also: <a href="https://www.calpers.ca.gov/documents/local-safety-member-3-at-55-benefit-factors-pdf/download?inline=">CalPERS Local Safety 3% at 55 Benefit Factors (PDF)</a>
* see also: <a href="https://www.calpers.ca.gov/documents/local-safety-member-25-at-55-benefit-factors-pdf/download?inline=">CalPERS Local Safety 2.5% at 55 Benefit Factors (PDF)</a>
* see also: <a href="https://www.calpers.ca.gov/documents/local-safety-member-27-at-57-benefit-factors-pdf/download?inline=">CalPERS Local Safety 2.7% at 57 (PEPRA) Benefit Factors (PDF)</a>
* see also: <a href="https://www.calpers.ca.gov/documents/local-safety-member-25-at-57-benefit-factors-pdf/download?inline=">CalPERS Local Safety 2.5% at 57 (PEPRA) Benefit Factors (PDF)</a>
* see also: <a href="https://www.calpers.ca.gov/documents/local-safety-member-2-at-57-benefit-factors-pdf/download?inline=">CalPERS Local Safety 2% at 57 (PEPRA) Benefit Factors (PDF)</a>

## CalPERS Formula Examples

#### Example: Classic 2% @ 55, Age 55, 25 Years of Service, Final Comp $4,500/month

<a href="https://news.calpers.ca.gov/have-you-checked-your-benefit-factor-chart/">Source: CalPERS PERSpective — Have You Checked Your Benefit Factor Chart?</a>

| Component | Value |
|-----------|-------|
| Service credit | 25 years |
| Benefit factor at age 55 | 2.0% |
| Final compensation | $4,500/month ($54,000/year) |
| **Calculation** | 25 × 2.0% × $4,500 = **$2,250/month ($27,000/year)** |

This member retires at the formula's "named" age (55) and receives exactly 50% of final compensation. By waiting to 63+, the benefit factor maxes at 2.5%, which would yield $2,812/month instead.

#### Example: Classic 2% @ 55, Age 63, 25.6 Years of Service, Final Comp $4,567/month

<a href="https://www.calpers.ca.gov/sources/member/CBEE/learning_guides/CalPERS_Retirement_Benefits-Early_thru_Mid-Career.pdf">Source: CalPERS Retirement Benefits — Early thru Mid-Career (PDF)</a>

| Component | Value |
|-----------|-------|
| Service credit | 25.6 years |
| Benefit factor at age 63 | 2.5% (maximum) |
| Final compensation | $4,567/month ($54,800/year) |
| **Calculation** | 25.6 × 2.5% × $4,567 = **$2,923/month ($35,076/year)** |

By working 6 months longer (gaining both service credit and a higher benefit factor at 63), this member receives $673/month more than the age-55 example — a 30% increase for just over half a year of additional service.

#### Example: PEPRA 2% @ 62, Age 62, 30 Years of Service, Final Comp $7,500/month

<a href="https://www.calpers.ca.gov/documents/state-miscellaneous-industrial-member-2-at-62-benefit-factors-pdf/download?inline=">Source: CalPERS 2% at 62 Benefit Factor Chart (PDF)</a>

| Component | Value |
|-----------|-------|
| Service credit | 30 years |
| Benefit factor at age 62 | 2.0% |
| Final compensation | $7,500/month ($90,000/year) |
| **Calculation** | 30 × 2.0% × $7,500 = **$4,500/month ($54,000/year)** |

This is the PEPRA "standard" retirement — 60% of final compensation at 30 years and age 62. Note that PEPRA's pensionable compensation is capped ($159,733 with Social Security in 2026), so very high earners will hit this ceiling.

#### Example: PEPRA 2% @ 62, Age 55, 20 Years of Service, Final Comp $6,000/month

<a href="https://www.calpers.ca.gov/documents/state-miscellaneous-industrial-member-2-at-62-benefit-factors-pdf/download?inline=">Source: CalPERS 2% at 62 Benefit Factor Chart (PDF)</a>

| Component | Value |
|-----------|-------|
| Service credit | 20 years |
| Benefit factor at age 55 | 1.3% |
| Final compensation | $6,000/month ($72,000/year) |
| **Calculation** | 20 × 1.3% × $6,000 = **$1,560/month ($18,720/year)** |

Early retirement under PEPRA carries a real cost — this member receives only 26% of final compensation compared to the 60% they'd get by waiting to 62 with 30 years. The benefit factor at 55 is 1.3% vs 2.0% at 62.

#### Example: Classic Safety 3% @ 50, Age 50, 25 Years of Service, Final Comp $10,000/month

| Component | Value |
|-----------|-------|
| Service credit | 25 years |
| Benefit factor at age 50 | 3.0% (maximum, does not increase with age) |
| Final compensation | $10,000/month ($120,000/year) |
| **Calculation** | 25 × 3.0% × $10,000 = **$7,500/month ($90,000/year)** |

The 3% @ 50 safety formula is the most generous in California — 75% of final compensation at just 25 years. A 30-year member gets 90%. This is the formula created by SB 400 in 1999.

#### Example: Two Employers, Different Formulas

<a href="https://www.calpers.ca.gov/sources/member/CBEE/learning_guides/CalPERS_Retirement_Benefits-Early_thru_Mid-Career.pdf">Source: CalPERS Retirement Benefits — Early thru Mid-Career (PDF)</a>

A member retiring at age 55 who worked 20 years under 2% @ 55 for one employer and 5 years under 2% @ 62 for another. CalPERS calculates each employer's portion separately:

| Employer | Formula | Service Credit | Benefit Factor at 55 | Final Comp | Pension |
|----------|---------|---------------|---------------------|------------|---------|
| Employer A | 2% @ 55 | 20 years | 2.0% | $5,000/mo | $2,000/mo |
| Employer B | 2% @ 62 | 5 years | 1.3% | $5,500/mo | $358/mo |
| **Combined** | | **25 years** | | | **$2,358/mo** |

This illustrates why the formula your employer contracts for matters — the same years of service produce very different benefit factors under different formulas.

---

## CalSTRS Formulas

| Formula | Applies To | Full Benefit Age | Max Factor | Career Factor |
|---------|-----------|-----------------|------------|---------------|
| <a href="https://www.calstrs.com/understanding-the-formula-calstrs-2-at-60">**2% @ 60**</a> | Members hired on/before 12/31/2012 | 60 | 2.4% at 63+ | +0.2% with 30+ years (up to max 2.4%) |
| <a href="https://www.calstrs.com/understanding-the-formula-calstrs-2-at-62">**2% @ 62** (PEPRA)</a> | Members hired on/after 1/1/2013 | 62 | 2.4% at 65+ | None |

<a href="https://www.calstrs.com/two-benefit-structures">CalSTRS 2% at 60 members</a> can retire as early as age 50 with 30 years of service, or age 55 with 5 years. CalSTRS 2% at 62 members can retire at the earliest at age 55 with 5 years.

For CalSTRS 2% at 60 with less than 25 years, final compensation is based on the highest 36 consecutive months. With 25+ years, it's the highest 12 consecutive months. All CalSTRS 2% at 62 members use 36 consecutive months regardless.

* see also: <a href="https://www.calstrs.com/age-factor">CalSTRS Age Factor Tables</a>
* see also: <a href="https://www.calstrs.com/files/1105a6846/UnderstandingTheFormula2025.pdf">CalSTRS Understanding the Formula 2025 (PDF)</a>
* see also: <a href="https://www.ctamemberbenefits.org/en/Retirement/Retirement---Benefits-Overview-of-CalSTRS-Benefits">CTA Retirement Benefits Overview</a>

## CalSTRS Formula Examples

#### Example: CalSTRS 2% @ 60, Age 63, 24 Years of Service, Final Comp $6,200/month

<a href="https://www.calstrs.com/files/1105a6846/UnderstandingTheFormula2025.pdf">Source: CalSTRS Understanding the Formula 2025 (PDF) — "Mariana" example</a>

| Component | Value |
|-----------|-------|
| Service credit | 24 years |
| Age factor at age 63 | 2.4% (maximum for 2% @ 60) |
| Final compensation | $6,200/month |
| **Calculation** | 24 × 2.4% × $6,200 = **$3,571/month ($42,854/year)** |

By retiring at 63 instead of 60, Mariana's age factor increased from 2.0% to the 2.4% maximum — a 20% boost to her benefit for each year of service.

#### Example: CalSTRS 2% @ 60, Age 60, 30 Years of Service, Final Comp $8,000/month

<a href="https://www.calstrs.com/understanding-the-formula-calstrs-2-at-60">Source: CalSTRS Understanding the Formula — 2% at 60</a>

| Component | Value |
|-----------|-------|
| Service credit | 30 years |
| Age factor at age 60 | 2.0% |
| Career factor (30+ years) | +0.2% (total age factor becomes 2.2%) |
| Final compensation | $8,000/month (highest 12 months, since 25+ years of service) |
| **Calculation** | 30 × 2.2% × $8,000 = **$5,280/month ($63,360/year)** |

The career factor is a CalSTRS-only bonus — members with 30+ years of service add 0.2% to their age factor (up to the 2.4% maximum). This means a teacher retiring at 60 with 30 years gets an effective 2.2% instead of 2.0%. Also note that with 25+ years, final compensation uses the highest 12 months instead of 36.

#### Example: CalSTRS 2% @ 62 (PEPRA), Age 62, 25 Years of Service, Final Comp $7,000/month

<a href="https://www.calstrs.com/understanding-the-formula-calstrs-2-at-62">Source: CalSTRS Understanding the Formula — 2% at 62</a>

| Component | Value |
|-----------|-------|
| Service credit | 25 years |
| Age factor at age 62 | 2.0% |
| Career factor | None (PEPRA members are not eligible) |
| Final compensation | $7,000/month (highest 36 months, mandatory for all PEPRA) |
| **Calculation** | 25 × 2.0% × $7,000 = **$3,500/month ($42,000/year)** |

Compare this to the Classic 2% @ 60 member at the same age and service: a Classic member at 62 would have a 2.4% age factor and could be using 12-month final comp (likely higher), resulting in a significantly larger benefit. PEPRA teachers also lose the career factor bonus.

---

## PEPRA — How the 2013 Reform Changed Formulas

The <a href="https://news.calpers.ca.gov/pepra-explained-addressing-the-top-questions-from-members/">California Public Employees' Pension Reform Act of 2013 (PEPRA)</a>, effective January 1, 2013, was the most significant pension reform in California history. It applies to **all** California public retirement systems — CalPERS, CalSTRS, 1937 Act counties, and independent city systems.

* see also: <a href="./california#how-we-got-here--the-road-from-sb-400-to-pepra-1999-2012">How We Got Here — The Road from SB 400 to PEPRA</a> — the full political history

### Key PEPRA Provisions

| Provision | Pre-PEPRA (Classic) | Post-PEPRA (New Members) |
|-----------|-------------------|--------------------------|
| Misc. formula | Varies (up to 3% @ 60) | Capped at 2% @ 62 |
| Safety formula | Up to 3% @ 50 | Capped at 2.7% @ 57 |
| Final comp period | 12 or 36 months | 36 months mandatory |
| Pensionable comp cap | IRC §401(a)(17) limit ($350,000 in 2026) | $159,733 (with SS) / $191,679 (without SS) for 2026 |
| Employee contribution | Varies by contract | 50% of normal cost (minimum) |
| Retroactive enhancements | Permitted | Prohibited |
| Pension holidays | Permitted | Prohibited |

### Who Is a "New Member" Under PEPRA?

You are a PEPRA "new member" if:
- You are hired into CalPERS membership **for the first time** on or after 1/1/2013
- You were previously a member of another California public system but had a **break in service greater than 6 months** before joining your new system
- You are not eligible for reciprocity

You are a **Classic member** if:
- You were a CalPERS member before 1/1/2013 and maintained continuous membership
- You moved to a new CalPERS employer **within 6 months** of separating from the old one
- You established reciprocity with another California public system

* see also: <a href="https://hr.sfsu.edu/calpers-retirement-benefits">SFSU CalPERS Retirement Benefits (Classic vs PEPRA)</a>
* see also: <a href="https://adminfinance.fresnostate.edu/hr/benefits/retirement/contributions.html">Fresno State Understanding Contributions</a>

---

## How Pension Formulas Get Determined at the Local Level

The pension formula for local agency employees is determined through a multi-step process:

1. **Contract with CalPERS:** The local agency <a href="https://www.calpers.ca.gov/employers/contracts/new-pension-contracts">selects a retirement formula from CalPERS' menu of available options</a> when it first contracts or when it amends its contract. This requires a board resolution and an actuarial valuation from CalPERS.
2. **Bargaining:** The bargaining unit and the agency negotiate whether to seek a formula change (enhancement or reduction). Any change to the CalPERS contract requires a formal contract amendment with CalPERS.
3. **CalPERS Actuarial Valuation:** CalPERS calculates the cost impact of any formula change and sets the resulting employer and employee contribution rates. The fee is <a href="https://www.calpers.ca.gov/employers/contracts/new-pension-contracts">$900 per actuarial valuation scenario</a>.
4. **Board Adoption:** The agency's governing body (city council, board of supervisors) must adopt a resolution approving the contract amendment.
5. **PEPRA Constraints:** Since 2013, <a href="https://www.calpers.ca.gov/documents/pas-ref-guide/download">PEPRA prohibits retroactive benefit enhancements</a> and caps formulas for new members at 2% @ 62 (miscellaneous) or 2.7% @ 57 (safety).

Different bargaining units within the same agency can (and often do) have **different pension tiers** — for example, a city might have Tier I (3% @ 60, pre-2011 hires), Tier II (2% @ 60, 2011-2012 hires), and Tier III/PEPRA (2% @ 62, post-2013 hires) for miscellaneous employees.

* see also: <a href="https://www.calpers.ca.gov/employers/contracts/pension-contract-agency-eligibility">CalPERS Pension Contract Agency Eligibility</a>
* see also: <a href="https://www.calpers.ca.gov/documents/200-082-01-attach1/download">CalPERS Optional Benefits Listing (PDF)</a>
* see also: <a href="./california#bargaining-units--state-level">California Bargaining Units</a> — the 21 state bargaining units and how MOUs work

---

## Who Determines California Pension Formulas?

California pension formulas are determined through a **combination of state statute, local bargaining, and CalPERS/CalSTRS board action** — a multi-layered process unlike the purely statutory federal or New York systems:

| Element | Who Decides | Authority |
|---------|------------|-----------|
| **Maximum formula caps** (e.g., PEPRA 2% @ 62) | State Legislature | <a href="https://news.calpers.ca.gov/pepra-explained-addressing-the-top-questions-from-members/">PEPRA (Gov. Code §7522 et seq.)</a> |
| **Menu of available formulas** | CalPERS | <a href="https://www.calpers.ca.gov/employers/contracts/new-pension-contracts">CalPERS contract options</a> |
| **Which formula a local agency adopts** | Local agency governing body + bargaining unit | <a href="https://www.calpers.ca.gov/employers/contracts/new-pension-contracts">CalPERS contract amendment</a>, negotiated through MOU process |
| **State employee formulas** | State Legislature + bargaining (MOUs ratified by Legislature) | Gov. Code; see <a href="./california#bargaining-units--state-level">California Bargaining Units</a> |
| **Employee contribution rates (Classic)** | Statute + MOU negotiation | Varies by bargaining unit |
| **Employee contribution rates (PEPRA)** | CalPERS actuarial valuation | <a href="https://www.calpers.ca.gov/employers/policies-and-procedures/pension-reform-impacts/public-agency-pepra-member-contribution-rates-faq">50% of normal cost per PEPRA (Gov. Code §7522.30)</a> |
| **Employer contribution rates** | CalPERS Board (based on actuarial valuation) | <a href="https://www.calpers.ca.gov/employers/actuarial-resources/employer-contributions">CalPERS annual valuation</a> — **not negotiable** |
| **CalSTRS contribution rates** | Teachers' Retirement Board (within limits set by AB 1469) | <a href="https://www.calstrs.com/files/be800640a/CalSTRSFundingPlan.pdf">CalSTRS Funding Plan</a> |

**The key distinction from federal/New York:** California unions can and do negotiate pension formula changes at the local level through MOUs. This is why different cities have different pension tiers — the formula you get depends on what your bargaining unit negotiated with your employer.

---

## Contribution Rates

Pensions are funded by three sources: employee contributions, employer contributions, and investment returns. The employer side is invisible on your paycheck but represents an enormous portion of total compensation that no private employer matches.

### CalPERS Contribution Rates (FY 2025-26)

**Employee contribution rates:**

| Category | Classic Members | PEPRA Members | How Rates Are Set |
|----------|----------------|---------------|-------------------|
| State Miscellaneous (with SS) | ~7% of pay (varies by bargaining unit, typically with $513/mo offset) | ~8% (50% of normal cost) | <a href="https://www.calpers.ca.gov/employers/policies-and-procedures/circular-letters/200-025-25">Classic: statute + MOU; PEPRA: Gov. Code §7522.30</a> |
| State Miscellaneous (no SS) | ~8% of pay | ~9% | Statute + MOU |
| State Safety (Peace Officers/Firefighters) | ~10–11% of pay | ~13.25% (50% of normal cost) | <a href="https://pecg.org/2025-2028-mou/article_11-6/">MOU (e.g., PECG Article 11.6)</a> |
| Local Miscellaneous | Varies by agency contract (typically 7–8%) | ~7.75% (varies by plan) | <a href="https://www.calpers.ca.gov/employers/policies-and-procedures/pension-reform-impacts/public-agency-pepra-member-contributions">CalPERS actuarial valuation</a> |
| Local Safety | Varies by agency contract (typically 9–12%) | ~13–14% (varies by plan) | CalPERS actuarial valuation |
| School Employees (classified staff) | 7% | 8% | <a href="https://www.calpers.ca.gov/employers/policies-and-procedures/circular-letters/200-027-25">Statute</a> |

**Employer contribution rates (FY 2025-26):**

| Category | Employer Rate (% of payroll) | Source |
|----------|------------------------------|--------|
| State Miscellaneous | ~30.87% | <a href="https://www.calpers.ca.gov/employers/policies-and-procedures/circular-letters/200-049-25">CalPERS Projected Employer Rates CL 200-049-25</a> |
| State Industrial | ~19.54% | Same source |
| State Safety (non-Peace Officer) | ~21.54% | Same source |
| State Peace Officers & Firefighters | **~46.26%** | Same source |
| Schools (classified staff pool) | <a href="https://www.calpers.ca.gov/employers/policies-and-procedures/circular-letters/200-027-25">26.81%</a> | CalPERS CL 200-027-25 |
| Local agencies | Varies widely by agency and plan | <a href="https://www.calpers.ca.gov/employers/actuarial-resources/employer-contributions">CalPERS Public Agency Required Employer Contributions search tool</a> |

Employer rates include both the normal cost (annual cost of benefits being earned) and payments toward any unfunded accrued liability (UAL). Rates change annually based on CalPERS actuarial valuations and are **not negotiable** — employers must pay the actuarially determined rate regardless of what bargaining units negotiate on the employee side.

* see also: <a href="https://www.calpers.ca.gov/employers/actuarial-resources/employer-contributions">CalPERS — Required Employer Contributions</a>
* see also: <a href="https://www.calstate.edu/csu-system/about-the-csu/budget/2026-27-operating-budget/Pages/Employer-Paid-Retirement-Adjustment.aspx">CSU — Employer-Paid Retirement Adjustment</a>
* see also: <a href="https://news.calpers.ca.gov/pepra-explained-addressing-the-top-questions-from-members/">CalPERS — PEPRA Explained</a>

### CalSTRS Contribution Rates (FY 2025-26)

CalSTRS has a unique **three-party funding model** — members, employers, and the state all contribute:

| Contributor | Rate | Set By |
|------------|------|--------|
| **Members (2% at 60, Classic)** | <a href="https://www.calstrs.com/contributions">10.25% of creditable earnings</a> | Statute (Education Code) |
| **Members (2% at 62, PEPRA)** | <a href="https://www.calstrs.com/contributions">~9% (50% of normal cost)</a> | PEPRA (Gov. Code §7522.30) |
| **Employers** (school districts) | <a href="https://www.calstrs.com/contributions">19.10% of creditable earnings</a> | <a href="https://www.calstrs.com/files/be800640a/CalSTRSFundingPlan.pdf">CalSTRS Funding Plan (AB 1469)</a> — Teachers' Retirement Board can adjust up to 1%/year, capped at 20.25% |
| **State of California** | <a href="https://www.calstrs.com/files/be800640a/CalSTRSFundingPlan.pdf">10.828%</a> of member earnings | CalSTRS Funding Plan — Board may adjust up to 0.5%/year |

Total contribution rate: approximately **40% of a teacher's salary** goes toward funding their pension from all three parties combined. This is one of the highest total pension funding rates in the country.

* see also: <a href="https://www.calstrs.com/contributions">CalSTRS — Contributions</a>
* see also: <a href="https://www.calstrs.com/files/be800640a/CalSTRSFundingPlan.pdf">CalSTRS Funding Plan Fact Sheet (PDF)</a>
* see also: <a href="https://www.calstrs.com/as-funded-status-rises-contribution-rates-to-remain-the-same">CalSTRS — Contribution Rates Holding Steady</a>

---

---

## Cost-of-Living Adjustments (COLA)

California public pensions include inflation protection, but it works **very differently** depending on your system.

### CalPERS COLA — Compounding 2%

CalPERS provides a **compounding** COLA based on the employer's contract with CalPERS. <a href="https://www.calpers.ca.gov/retirees/cost-of-living/cola">95.8% of CalPERS retirees have a 2% COLA provision</a>; the remaining 4.2% have contracts for 3%, 4%, or 5%.

Each year, CalPERS compares:
1. The **compounded rate of inflation** (using the U.S. City Average CPI) since your retirement
2. The **compounded contracted COLA rate** (e.g. 2% per year)

You receive whichever is lower, applied to your **base allowance** — the gross amount you received at the time of retirement.

| Year | Compounded COLA Factor (2% provision) | Cumulative adjustment |
|------|---------------------------------------|----------------------|
| 1 | 1.0200 | +2.00% |
| 5 | 1.1041 | +10.41% |
| 10 | 1.2190 | +21.90% |
| 20 | 1.4859 | +48.59% |
| 30 | 1.8114 | +81.14% |

A $50,000 pension grows to **$90,568/year** after 30 years of 2% compounding.

**COLA Bank:** When inflation in a given year falls below your contracted cap, the unused portion accumulates in a "COLA bank." In future years when inflation exceeds the cap, CalPERS can draw from your bank to provide a COLA above the cap. This means you never "lose" inflation protection — it's deferred, not forfeited.

**Purchasing Power Protection Allowance (PPPA):** If accumulated COLA has not kept pace with inflation, CalPERS issues a supplemental payment to prevent your purchasing power from falling below **75%** (state and school employers) or **80%** (public agency employers) of its original value.

* see also: <a href="https://www.calpers.ca.gov/retirees/cost-of-living/cola">CalPERS — Cost-of-Living Adjustment (COLA)</a>
* see also: <a href="https://news.calpers.ca.gov/about-your-cola-and-inflation/">CalPERS PERSpective — About Your COLA and Inflation</a>

### CalSTRS COLA — Simple (Non-Compounding) 2%

CalSTRS provides a fundamentally different type of inflation protection. <a href="https://www.calstrs.com/inflation-protection">The annual benefit adjustment is 2% of the member's **original retirement benefit**</a> — it does **not** compound.

| Year | Annual increase (on $50K original benefit) | Cumulative pension |
|------|-------------------------------------------|-------------------|
| 1 | +$1,000 | $51,000 |
| 5 | +$1,000 | $55,000 |
| 10 | +$1,000 | $60,000 |
| 20 | +$1,000 | $70,000 |
| 30 | +$1,000 | $80,000 |

A $50,000 CalSTRS pension grows to **$80,000/year** after 30 years — compared to $90,568 under CalPERS compounding. That **$10,568/year gap** is the cost of non-compounding.

**Supplemental Benefit Maintenance Account (SBMA):** To prevent severe erosion, CalSTRS maintains a <a href="https://www.calstrs.com/supplemental-payments-calculation-and-funding-information">purchasing power floor of **85%**</a> of the pension's original value. Once your purchasing power falls below 85%, CalSTRS issues quarterly supplemental payments to make up the difference. The SBMA payment is **not** capped at 2% — it increases at the actual rate of inflation. The 85% floor is more protective than CalPERS's 75% floor, partially offsetting the disadvantage of non-compounding.

Under the CalSTRS 2014 Funding Plan, the Legislature **cannot reduce** the 2% annual benefit adjustment for members who retire on or after January 1, 2014.

* see also: <a href="https://www.calstrs.com/inflation-protection">CalSTRS — Inflation Protection</a>
* see also: <a href="https://www.cft.org/article/how-calstrs-and-calpers-pensions-are-protected-inflation">CFT — How CalSTRS and CalPERS Pensions Are Protected from Inflation</a>
* see also: <a href="https://www.calstrs.com/supplemental-payments-calculation-and-funding-information">CalSTRS — Supplemental Payments Funding and Estimation</a>

### CalPERS vs CalSTRS COLA Comparison

| Feature | CalPERS | CalSTRS |
|---------|---------|---------|
| Type | **Compounding** | **Simple (non-compounding)** |
| Rate | 2% (95.8% of retirees) | 2% of original benefit |
| Applied to | Base allowance (compounds each year) | Original retirement amount (fixed increment) |
| $50K pension after 30 years | **$90,568** | **$80,000** |
| Inflation banking | COLA Bank (unused adjustment stored) | None |
| Purchasing power floor | 75% (PPPA) or 80% for agencies | **85%** (SBMA) |
| Floor adjustment rate | At contracted cap | At actual inflation (uncapped) |

The key tradeoff: CalPERS compounding produces higher income over time, but CalSTRS's higher floor (85% vs 75%) provides a stronger safety net during periods of high inflation.


## Key Formula Terms

| Term | Definition |
|------|-----------|
| **Classic Member** | A CalPERS/CalSTRS member who first joined before 1/1/2013 and has maintained continuous membership or reciprocity |
| **PEPRA Member** | A "new member" who first joined a California public system on or after 1/1/2013 without reciprocity |
| **Benefit Factor / Age Factor** | The percentage of final compensation earned per year of service, which increases with retirement age |
| **Final Compensation** | Highest average annual salary over 12 or 36 consecutive months (depending on formula and hire date) |
| **Service Credit** | Total years and partial years of qualifying employment |
| **Normal Cost** | The annual cost of pension benefits earned during the current year, expressed as a percentage of payroll |
| **Employer Contribution Rate** | The percentage of payroll an employer must pay to CalPERS/CalSTRS, determined annually by actuarial valuation — includes normal cost plus unfunded liability payments |
| **COLA** | Cost-of-living adjustment — <a href="https://legalclarity.org/how-does-calpers-work-pension-benefits-explained/">typically 2% annual cap for most CalPERS contracts</a> |
| **COLA Bank** | Accumulated unused COLA when inflation is below the contracted cap, applied in future high-inflation years |
| **EPMC** | Employer Paid Member Contributions — when the employer pays part or all of the employee's required contribution (common in pre-PEPRA MOUs) |
| **UAL** | Unfunded Accrued Liability — the gap between promised benefits and current fund assets; employer rates include UAL amortization payments |
| **Vesting** | Achieving eligibility for a pension benefit — typically 5 years of service credit |

---

*Last updated: April 2026. This guide is for informational purposes only. Pension laws are complex and subject to change. For individual benefit questions, contact your retirement system directly.*
